package mynewpackage;
import org.testng.annotations.Test;

public class MyCases {
	
	@Test
	public void testOne() {
		System.out.println("this is my first test");
	}
	
	@Test
	public void testTwo() {
		System.out.println("this is my second test");
	}
	
	@Test
	public void testThree() {
		System.out.println("this is my third test");
	}
	
	@Test
	public void testFour() {
		System.out.println("this is my fourth test");
	}
	
	@Test
	public void testFive() {
		System.out.println("this is my fifth test");
	}
	
	@Test
	public void testSix() {
		System.out.println("this is my sixth test");
	}

}
